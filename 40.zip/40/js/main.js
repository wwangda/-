var MAX_NUMBER = '115792089237316195423570985008687907853269984665640564039457584007913129639935';

var allowanceAmount = 0;

var web3js;
var web3;
var defaultaccount='';
var address='';
var id;
var contract = '0x4bbd41f958ab065c71539a405c7a8c1ae33c2df0';
var USDTContractAddress = '0x55d398326f99059fF775485246999027B3197955';
//
//0xbA2aE424d960c26247Dd6c32edC70B295c744C43
var IDOCI;
var USDTCI;


var totalSupply;

var isDespoit = false;

var ref = getUrlParam('ref');

var myReward;

$(function() {
	
	setTimeout("initWallet()", 500);
	//setTimeout("initWallet()", 2000);

	var clipboard = new ClipboardJS('.copySpan');
	clipboard.on('success', function(e) {
		console.info('Action:', e.action);
		console.info('Text:', e.text);
		console.info('Trigger:', e.trigger);
		e.clearSelection();
		alert('Copy Successful');
	});
	clipboard.on('error', function(e) {
		console.error('Action:', e.action);
		console.error('Trigger:', e.trigger);
		alert('Copy fail');
	});
})

async function initWallet() {

	console.log('initWallet');console.log(defaultaccount.length);
	var web3Provider;
	if(defaultaccount.length > 0){
		//return;
	}
	if (window.ethereum) {
		web3Provider = window.ethereum;
		try {
			
			await window.ethereum.enable();
		} catch (error) {
			
			//console.error("User denied account access")
			alert(language[currLang]['msg1']);return;
		}
	} else if (window.web3) {   
		web3Provider = window.web3.currentProvider;
	} else {
		//web3Provider = new Web3.providers.HttpProvider('http://localhost:8545');
		alert(language[currLang]['msg2']);return;
	}
	web3js = web3 = new Web3(web3Provider);
	
	var MyContract=new web3js.eth.Contract(abi,contract);
	IDOCI = MyContract.methods;

	var USDTContract=new web3js.eth.Contract(usdtabi,USDTContractAddress);
	USDTCI = USDTContract.methods;

	
	var LastAccount='';
	var tim=setInterval(function(){
		web3js.eth.getAccounts(function (error, result) {
			if (!error){
				if (LastAccount != result[0]){
					LastAccount=result[0];
					get_info( result[0]);
				}
			}
		});	    
	},1000);
	
	
}

function get_info(addr){
	
	defaultaccount = addr;

	var len = defaultaccount.length;console.log('len:'+len);
	var shortAddress = defaultaccount.substring(0, 4)+'...'+defaultaccount.substring(len-4);
	$('.address').html(shortAddress);
	
	$('.copySpan').attr('data-clipboard-text', defaultaccount);
	
	$('.unconnect').hide();
	$('.account-basic-info, .account-basic-info-m').show();
	$('.create_btn').removeClass('gray');
	console.log(defaultaccount);

	$('.referralLink').html('https://'+window.location.host+'/?ref='+defaultaccount.substring(0, 4)+'...'+defaultaccount.substring(len-4));
	$('#copySpan2').attr('data-clipboard-text','https://'+window.location.host+'/?ref='+defaultaccount);

	getUserInfo();
			
}

function getUserInfo() {

	IDOCI.getBalance().call(function (error,res){
				
		if(error) {
			console.log(error);
		} else {
			var totalBalance = web3js.utils.fromWei(res, 'ether') ;
		//var totalBalance = 26580.6598;

			totalBalance = parseFloat(totalBalance).toFixed(4);
	
			$(".totalBalance").html(totalBalance);
		}
			

		
	});

	
	USDTCI.balanceOf(defaultaccount).call(function (error, res) {
		if(error) {
			console.log(error);
		} else {

			var myBalance = web3js.utils.fromWei(res, 'ether');
		//var myBalance = 2450.654544;
			myBalance = parseFloat(myBalance).toFixed(4);

			$(".myBalance").html(myBalance);
		}
	});


	IDOCI.hatcheryMiners(defaultaccount).call(function (error,res){
				
		if(error) {
			console.log(error);
		} else {

			var hatcheryMiners = res;

			$(".myHatcheryMiners").html(hatcheryMiners);
		}
	});



	IDOCI.getMyEggs().call({
		from:defaultaccount
	},function (error,res){
				
		if(error) {
			console.log(error);
		} else {

			var eggsSinceLastHatch = res;

			if(eggsSinceLastHatch > 0) {
				IDOCI.calculateEggSell(eggsSinceLastHatch).call(function (error,res){
					
					if(error) {
						console.log(error);
					} else {
			
						myReward = web3js.utils.fromWei(res, 'ether');

						myReward = parseFloat(myReward);
				
						$(".myReward").html(myReward.toFixed(8));
					}
				});
			}
		}

	});

	
}



setInterval(function() {

	getApprove();

	getUserInfo();
},
3000);



function getApprove() {

    USDTCI.allowance(defaultaccount, contract).call((err, res) => {

		if(err)
			return;

        allowanceAmount = web3js.utils.fromWei(res, 'ether');
		
		if(!isDespoit) {
			if(isApprove()) {
				$('.buyButtonP').html("参与USDT");
				
			} else {
				$('.buyButtonP').html("参 与");
			}
		}
		

	});

    
}


function isApprove() {
    return allowanceAmount > 0;
}



function approve() {

	USDTCI.approve(contract, MAX_NUMBER).send({
		from:defaultaccount
	},(err, res) => {

			if(err)
				return;

			alert("参与成功，请等待区块确认");

	});
		
		
}

async function buyEggs() {

	var referrer = ref;	

	if(typeof referrer ==='undefined' ||  referrer===null){
		referrer = '0x0000000000000000000000000000000000000000';
	}

	if(isApprove()) {

        var pay_amount = $('input[name="ethAmount"]').val();

        if(pay_amount <= 0) {
            alert("Please enter the Invest amount");
            return;
        }
        await USDTCI.balanceOf(defaultaccount).call(function (err, res) {
            if(err)
                return;

            var ethAmount = web3js.utils.fromWei(res, 'ether');
            if(ethAmount < pay_amount) {
				alert("Insufficient balance");

            }else {
                
				
                    
                IDOCI.buyEggs(web3js.utils.toWei(pay_amount.toString(), 'ether'),referrer).send({
                    from:defaultaccount
                },(err, res) => {
        
                        if(err)
                            return;
        
						alert("参与成功，请等待区块确认");
                });
                    
                
            }
        });
	} else {
		approve();
	}
}


async function sellEggs() {
                 
	IDOCI.sellEggs().send({
		from:defaultaccount
	},(err, res) => {

			if(err)
				return;

			alert("提取成功，请等待区块确认");
	});
                    
            
}

async function hatchEggs() {

	if(myReward < 0.01) {

		alert("产量必须大于0.01 USDT");
		return;
	}
    
	var referrer = referrer;	
	if(typeof referrer ==='undefined' ||  referrer===null){
		referrer = '0x0000000000000000000000000000000000000000';
	}


	IDOCI.hatchEggs(referrer).send({
		from:defaultaccount
	},(err, res) => {

			if(err)
				return;

			alert("继续参与成功，请等待区块确认");
	});
                    
            
}


function getUrlParam(name) {
	var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
	var r = window.location.search.substr(1).match(reg);
	if (r != null) 
	  return unescape(r[2]); 
	  
	return '0x0000000000000000000000000000000000000000';
}