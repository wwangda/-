var currLang;
var language={
    "zh":{
        'lan0':'获取NRG权益',
        'lan1':'',
        'lan2':'幸运宇宙智能合约生态构建与全球Matrix Foundation达成战略合作，为提供流动性的个人、平台和机构针对不同产品产出利润的聚合平台，它通过全球Matrix Foundation市值管理重新平衡数据得出智能合约合同交易互动中的最高利润，宇宙能量（Cosmic Energy）简称NRG，总量1万亿，交易燃烧9%（6%用于持币分红，3%用于销毁），NRG是智能合约的燃料，将其以不可更改的分配模型智能化分发给所有贡献者，幸运宇宙智能合约生态构建最大的愿望是通过宇宙能量NRG唤醒宇宙能量NRG-DAO去中心化社区组织，智能合约执行宇宙能量公链卡路里CALORIE只涨不跌，解决土狗给行业带来的信任危机，助推LUCKS（幸运儿）对标YFI并超越BTC。<br>幸运宇宙智能合约是为分散式金融（DeFi）投资者提供的汇总服务，它使用自动化使他们从收益中获得最大利润。除此之外，幸运宇宙智能合约还会上线借贷、保险、信托、元宇宙游戏等板块。<br>它的目标是为不熟悉技术或希望以比认真交易者更少投入的方式进行互动的投资者简化不断扩大的DeFi空间。',
        'lan3':'我的地址：',

        'lan4':'已参与',
        'lan5':'获取',
        'lan51':'已关闭',
        'lan6':'授权',
        'lan7':'领取',

        'lan11':'NRG的数量：',
        'lan12':'NRG的待领取数量：',
        'lan13':'NRG的已领取数量：',
        'lan14':'NRG 数据：',
        'lan15':'NRG 总数：',
        'lan16':'NRG 销毁数量：',
        'lan17':'NRG 市值：',
        'lan18':'NRG 持币地址数量：',
        'lan19':'推荐奖励：',
        'lan20':'用户信息',
        'lan21':'NRG权益总次数：',
        'lan22':'NRG权益已领取次数：',
        'lan23':'NRG权益剩余领取次数：',
        'lan24':'复制邀请链接',

        'lan33':'连接钱包',
        'lan34':'宇宙能量IDO起飞计划',
        'lan341':'宇宙能量太空加油站',
        'lan342':'宇宙能量星球合成站',
        'lan35':'宇宙能量DAO共识计划',
        'lan36':'宇宙能量星球探索计划',
        'lan37':'宇宙能量白皮书',

        'lan38':'审计报告',
        'lan39':'推特',
        'lan40':'邮箱',

        'lan41':'太空加油A站（贡献200万枚NRG）',
        'lan42':'太空加油B站（贡献500万枚NRG）',
        'lan43':'太空加油C站（贡献1000万枚NRG）',

        'msg1':'为了更好的为您提供服务，请同意授权',
        'msg2':'请下载TP,或火币钱包进行链接',

        'msg3':'复制成功',
        'msg4':'复制失败',

        'msg5':'授权成功，请等待区块确认',
        'msg6':'获取成功，请等待区块确认！',
        'msg7':'提取成功，请等待区块确认！',

        'msg8':'USDT余额不足',
        'msg9':'NRG余额不足'
    },

    "en":{
        'lan0':'Get NRG rights',
        'lan1':'',
        'lan2':'Lucky Universe smart contract ecological construction has reached a strategic cooperation with the global Matrix Foundation. It is an aggregation platform for individuals, platforms and institutions that provide liquidity to generate profits for different products. It rebalances data through the global Matrix Foundation market value management to obtain smart contract transactions. The highest profit in the interaction, Cosmic Energy (NRG for short), the total amount is 1 trillion, and the transaction burns 9% (6% is used for holding dividends and 3% is used for destruction). NRG is the fuel of smart contracts. It is distributed intelligently to all contributors with an unchangeable distribution model. The biggest wish of Lucky Universe smart contract ecological construction is to awaken the NRG-DAO decentralized community organization through the universe energy NRG, and the smart contract executes the universe energy public chain Calorie CALORIE only Ups and downs, solve the trust crisis brought by Tugou to the industry, and boost LUCKS (lucky ones) to benchmark YFI and surpass BTC. <br>Lucky Universe Smart Contract is an aggregation service for Decentralized Finance (DeFi) investors that uses automation to allow them to maximize their profits from their earnings. In addition, the Lucky Universe smart contract will also be launched on loan, insurance, trust, metaverse games and other sectors. <br>Its goal is to simplify the ever-expanding DeFi space for investors who are unfamiliar with technology or want to interact in a way that requires less investment than serious traders.',
        'lan3':'My address:',

        'lan4':'has been involved',
        'lan5':'Get',
        'lan51':'Close',
        'lan6':'Approve',
        'lan7':'Claim',

        'lan11':'My NRG balance:',
        'lan12':'My NRG pending:',
        'lan13':'My NRG claimed:',
        'lan14':'Cosmic Energy (NRG) data:',
        'lan15':'Total Supply:',
        'lan16':'Total Burned:',
        'lan17':'Market CAP:',
        'lan18':'Holders:',
        'lan19':'Recommendation reward:',
        'lan20':'User Information',
        'lan21':'Number of times Total NRG reward:',
        'lan22':'Number of times claimed:',
        'lan23':'Remaining number of times NRG reward:',
        'lan24':'Copy invitation link',

        'lan33':'Connect wallet',
        'lan34':'Cosmic Energy Takeoff Project',
        'lan341': 'Cosmic Energy Space Station',
        'lan342': 'Cosmic Energy Planet Station',
        'lan35':'Cosmic Energy DAO Consensus Project',
        'lan36':'Cosmic Energy Planet Exploration Project',
        'lan37':'Cosmic Energy White Paper',
        'lan38':'Audit report',
        'lan39':'Twitter',
        'lan40':'Mail',

        'lan41': 'Gas Station A (Supply 2 million NRG)',
        'lan42': 'Gas Station B (Supply 5 million NRG)',
        'lan43': 'Gas Station C (Supply 10 million NRG)',

        'msg1':'In order to better serve you, please agree to the authorization',
        'msg2':'Please download TP, or link with Huobi Wallet',

        'msg3':'Copy successful',
        'msg4':'Copy failed',

        'msg5':'Approve is successful, please wait for block confirmation',
        'msg6':'Get successful, please wait for block confirmation! ',
        'msg7':'Claim successful, please wait for the block confirmation! ',

        'msg8':'USDT balance is insufficient',
        'msg9':'NRG balance is insufficient'
    },

    "ja":{
        'lan0':'NRG権限を取得',
        'lan1':'',
        'lan2':'ラッキーユニバースのスマートコントラクトエコロジカルコンストラクションは、グローバルMatrix Foundationと戦略的協力関係にあります。これは、さまざまな製品の利益を生み出すための流動性を提供する個人、プラットフォーム、および機関向けの集約プラットフォームです。グローバルMatrix Foundationの市場価値管理を通じて、データのバランスを取り直します。スマートコントラクトトランザクションを取得します。インタラクションで最も高い利益であるCosmicEnergy（略してNRG）は、合計金額が1兆で、トランザクションは9％を消費します（6％は配当の保持に使用され、3％は破​​棄に使用されます）。 NRGはスマートコントラクトの原動力であり、不変の分配モデルですべての貢献者にインテリジェントに分配されます。ラッキーユニバースのスマートコントラクトエコロジカル構築の最大の願いは、宇宙エネルギーNRGとスマートを通じてNRG-DAO分散型コミュニティ組織を目覚めさせることです。契約は、宇宙エネルギーのパブリックチェーンであるCalorie CALORIEのみを実行し、浮き沈みのみを実行し、Tugouが業界にもたらした信頼の危機を解決し、LUCKS（幸運なもの）を後押ししてYFIのベンチマークを行い、BTCを上回ります。 <br> Lucky Universe Smart Contractは、分散型ファイナンス（DeFi）投資家向けの集約サービスであり、自動化を使用して収益からの利益を最大化できるようにします。さらに、ラッキーユニバースのスマートコントラクトは、ローン、保険、信託、メタバースゲーム、その他のセクターでも開始されます。 <br>その目標は、テクノロジーに不慣れな投資家や、真面目なトレーダーよりも少ない投資でやり取りしたい投資家のために、拡大し続けるDeFiスペースを簡素化することです。',
        'lan3':'私の住所：',

        'lan4':'関与しています',
        'lan5':'取得',
        'lan51':'Close',
        'lan6':'認証',
        'lan7':'受信済み',

        'lan11':'私のNRG番号：',
        'lan12':'受け取る金額：',
        'lan13':'受け取った金額：',
        'lan14':'宇宙エネルギー（NRG）データ：',
        'lan15':'総供給量：',
        'lan16':'破壊された量：',
        'lan17':'市場価値：',
        'lan18':'コイン保持アドレスの数：',
        'lan19':'推奨報酬：',
        'lan20':'ユーザー情報',
        'lan21':'NRG権利の総数：',
        'lan22':'受信したNRGの数：',
        'lan23':'NRGクレームの残りの数：',
        'lan24':'招待リンクをコピー',

        'lan33':'ウォレットを接続',
        'lan34':'宇宙エネルギー離陸プロジェクト',
        'lan341':'宇宙エネルギー宇宙ガソリンスタンド',
        'lan342':'宇宙エネルギー惑星ステーション',
        'lan35':'宇宙エネルギーDAOコンセンサスプロジェクト',
        'lan36':'宇宙エネルギー惑星探査プロジェクト',
        'lan37':'宇宙エネルギーホワイトペーパー',

        'lan38':'監査レポート',
        'lan39':'Twitter',
        'lan40':'メールボックス',

        'lan41':'Aステーション (200万NRGを供給する)',
        'lan42':'Bステーション (500万NRGを供給する)',
        'lan43':'Cステーション (1000万NRGを供給する)',

        'msg1':'より良いサービスを提供するために、承認に同意してください',
        'msg2':'TPをダウンロードするか、Huobi Walletとリンクしてください',

        'msg3':'コピー成功',
        'msg4':'コピーに失敗しました',

        'msg5':'認証は成功しました。ブロックの確認をお待ちください',
        'msg6':'成功します。ブロックの確認をお待ちください。 ',
        'msg7':'抽出は成功しました。ブロックの確認をお待ちください！ ',

        'msg8':'USDTバランスが不十分です',
        'msg9':'NRG バランスが不十分です'
    },

    "ko":{
        'lan0':'NRG 권한 가져오기',
        'lan1':'',
        'lan2':'Lucky Universe의 스마트 계약 생태 건설은 글로벌 Matrix Foundation과 전략적 협력에 도달했습니다.유동성을 제공하여 다양한 제품에 대한 수익을 창출하는 개인, 플랫폼 및 기관을 위한 집합 플랫폼입니다.글로벌 Matrix Foundation 시장 가치 관리를 통해 데이터 균형을 재조정하여 스마트 계약 거래 획득 상호 작용에서 가장 높은 수익을 내는 Cosmic Energy(NRG), 총 금액은 1조이며 거래는 9%를 소각합니다(6%는 배당금 보유에 사용하고 3%는 파괴에 사용). NRG는 스마트 계약의 연료이며 불변의 분배 모델로 모든 기여자에게 지능적으로 분배됩니다. Lucky Universe 스마트 계약 생태 건설의 가장 큰 소원은 우주 에너지 NRG를 통해 NRG-DAO 분산 커뮤니티 조직을 깨우고 스마트 계약은 우주 에너지 공개 체인 칼로리 CALORIE만 기복을 실행하고 Tugou가 업계에 가져온 신뢰 위기를 해결하고 LUCKS(운이 좋은 것)를 끌어 올려 YFI를 벤치마킹하고 BTC를 능가합니다. <br>Lucky Universe Smart Contract는 DeFi(Decentralized Finance) 투자자를 위한 집계 서비스로 자동화를 통해 수익을 극대화할 수 있습니다. 또한 Lucky Universe 스마트 계약은 대출, 보험, 신탁, 메타버스 게임 및 기타 분야에서도 출시될 예정입니다. <br>그 목표는 기술에 익숙하지 않거나 진지한 거래자보다 적은 투자가 필요한 방식으로 상호 작용하려는 투자자를 위해 계속 확장되는 DeFi 공간을 단순화하는 것입니다. ',
        'lan3':'내 주소:',

        'lan4': '관련되었습니다',
        'lan5': '가져오기',
        'lan51':'Close',
        'lan6': '권한 부여',
        'lan7': '수신',

        'lan11':'내 NRG 번호:',
        'lan12':'받을 금액:',
        'lan13':'받은 금액:',
        'lan14':'우주 에너지(NRG) 데이터:',
        'lan15':'총 공급량:',
        'lan16':' 파괴된 수량:',
        'lan17':' 시장 가치:',
        'lan18':'코인 보유 주소 수:',
        'lan19':'추천 보상:',
        'lan20': '사용자 정보',
        'lan21':'총 NRG 권한 수:',
        'lan22':'받은 NRG 수:',
        'lan23':'남은 NRG 클레임 수:',
        'lan24':'초대 링크 복사',

        'lan33': '지갑 연결',
        'lan34': '우주에너지 도약 프로젝트',
        'lan341': '우주 에너지 우주 주유소',
        'lan342': '우주 에너지 행성 스테이션',
        'lan35': '우주에너지 DAO 합의 프로젝트',
        'lan36': '우주 에너지 행성 탐사 프로젝트',
        'lan37': '우주 에너지 백서',

        'lan38': '감사 보고서',
        'lan39': '트위터',
        'lan40': '사서함',

        'lan41': '주유소 A (200만 NRG 공급)',
        'lan42': '주유소 B (500만 NRG 공급)',
        'lan43': '주유소 C (1000만 NRG 공급)',

        'msg1': '더 나은 서비스를 제공하기 위해 승인에 동의하십시오',
        'msg2':'TP를 다운로드하거나 후오비 지갑에 연결하세요',

        'msg3':'복사 성공',
        'msg4': '복사 실패',

        'msg5':'승인에 성공했습니다. 차단 확인을 기다리십시오.',
        'msg6':'성공했습니다. 차단 확인을 기다리십시오! ',
        'msg7':'추출에 성공했습니다. 차단 확인을 기다리십시오! ',

        'msg8':'USDT 잔액이 부족합니다',
        'msg9':'NRG 잔액이 부족합니다'
    },
};
function select_lang(languag,name){
    document.body.style.display='inline';
    document.getElementById('lang_name').innerHTML=name;
    document.getElementById('lang_box').style.display='none';

    $('#select_box').show();
    
    currLang=languag;
    try{
        var img='/image/lang/'+languag+'.png';
        document.getElementById('lang_img_box').src=img;
    
        var elem=document.getElementsByClassName("lang");//$(".lang");
        var test;
        var l=elem.length;
        for(var i=0;i<l;i++){
            if(typeof  elem[i]=='undefined')continue;
            test=language[languag][elem[i].dataset['attr_lang']]; 
            elem[i].innerHTML=test;
        } 
        var l={'sh':languag,'lh':name};
        localStorage.setItem("DEX_LANGUAGE",JSON.stringify(l));	
    }catch(e){alert(e);}
    if(defaultaccount.length > 0)get_info(defaultaccount);
    document.body.style.display='inline';

    

}



function select_first(){
    var l=JSON.parse(localStorage.getItem("DEX_LANGUAGE"));	
    //alert(JSON.stringify(l));
    if(typeof l ==='undefined' ||  l===null){
        l={'sh':'en','lh':'English'};
    }
    select_lang(l.sh,l.lh);
}


function on_select(){
    document.getElementById('lang_box').style.display='block';

    $('#select_box').hide();
}







